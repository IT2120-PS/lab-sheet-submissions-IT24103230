setwd("C:\\Users\\ASUS\\OneDrive\\Desktop\\Lab07")

# Q1 - Train Arrival (Uniform Distribution)
punif(25, 0, 40) - punif(10, 0, 40)

# Q2 - Software Update (Exponential Distribution)
pexp(2, rate = 1/3)

# Q3 - IQ Scores (Normal Distribution)
1 - pnorm(130, 100, 15)

# Q4 - IQ Scores for 95th Percentile
qnorm(0.95, 100, 15)
