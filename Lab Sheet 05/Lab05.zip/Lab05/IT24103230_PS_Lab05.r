setwd("C:\\Users\\ASUS\\OneDrive\\Desktop\\Lab05")

## 1
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")
time <- Delivery_Times$Delivery_Time_.minutes.

## 2
breaks = seq(20,70,length =10,)
hist(time,main = "Histogram of Delivery Times", right = FALSE, xlab = "Delivery Times")

## 3
freq <- table(cut(time, breaks = breaks, right = FALSE))
cumfreq <- cumsum(freq)
plot(breaks[-1], cumfreq, type = "1", main = "Cumulative Frequency Polygon(Ogive)", xlab = "Delivery Time(minutes", ylab = "Cumulative Frequency")
