## Lab 06
## IT24103230


## 1
# i. Binomial distribution: n = 44, p = 0.92
n <- 44
p <- 0.92

# ii.
dbinom(40, size = n, prob = p)

# iii.
pbinom(35, size = n, prob = p)

# iv.
1 - pbinom(37, size = n, prob = p)

# v.
pbinom(42, size = n, prob = p) - pbinom(39, size = n, prob = p)

## 2
# ii.
lambda <- 5

# iii.
dpois(6, lambda = lambda)

# iv.
1 - ppois(6, lambda = lambda)

## 3
# i.
n_students <- 50
p_pass <- 0.85

# ii.
1 - pbinom(46, size = n_students, prob = p_pass)

## 4
# ii.
lambda_calls <- 12

# iii.
dpois(15, lambda = lambda_calls)

