setwd("C:\\Users\\ASUS\\OneDrive\\Desktop\\Lab_09")
getwd()

# Part (i) - Generate random sample
set.seed(123)
sample_size <- 25
mean_time <- 45
sd_time <- 2

baking_time <- rnorm(sample_size, mean = mean_time, sd = sd_time)
print(baking_time)

# Part (ii) - Hypothesis test
# H0: mu = 46
# H1: mu < 46

t_test_result <- t.test(baking_time, mu = 46, alternative = "less")
print(t_test_result)

